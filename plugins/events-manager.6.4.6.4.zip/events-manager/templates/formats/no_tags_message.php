<?php
sprintf(__( 'No %s', 'events-manager'),__('Tags','events-manager'));