<div class="em-item em-location">
	<div class="em-item-image {no_loc_image}has-placeholder{/no_loc_image}" style="max-width:120px">
		{has_loc_image}
		<a href="#_LOCATIONURL">#_LOCATIONIMAGE{120,120}</a>
		{/has_loc_image}
		{no_loc_image}
		<a href="#_LOCATIONURL" class="em-item-image-placeholder"></a>
		{/no_loc_image}
	</div>
	<div class="em-item-info">
		<div class="em-item-name">#_LOCATIONLINK</div>
		<div class="em-item-meta">
			<div class="em-item-meta-line em-location-address">
				<span class="em-icon em-icon-location"></span>
				<p>#_LOCATIONADDRESS<br>#_LOCATIONTOWN</p>
			</div>
		</div>
	</div>
</div>