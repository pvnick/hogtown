<?php
// as of version 6, this is not to be used further, see file below
include( em_locate_template('calendar/calendar.php') );