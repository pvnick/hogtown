<?php
/**
 * Deprecated functions.
 *
 * @deprecated 2.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * @deprecated 2.4.0
 */
function bp_group_avatar_edit_form() {
	_deprecated_function( __FUNCTION__, '2.4' );
}

/**
 * @deprecated 2.4.0
 *
 * @param bool $deprecated Param deprecated 1.1.0
 */
function groups_avatar_upload( $deprecated = true ) {
	_deprecated_function( __FUNCTION__, '2.4' );
}
