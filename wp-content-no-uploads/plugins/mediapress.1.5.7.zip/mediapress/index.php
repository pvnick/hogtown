<?php
//welcome to the world of MediaPress
//This file is here to prevent people from directly accessing/listing the files of this folder via web
//
//please see mediapress.php for the main plugin file
