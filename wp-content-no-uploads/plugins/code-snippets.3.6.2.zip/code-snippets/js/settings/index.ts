import { handleSettingsTabs } from './tabs'
import { handleEditorPreviewUpdates } from './editor-preview'

handleSettingsTabs()
handleEditorPreviewUpdates()
